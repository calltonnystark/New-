export const educations = [
  {
    id: 1,
    title: "Bachelor Degree",
    duration: "2022 - Present",
    institution: "Maharishi Markandeshwar Deemed to be University",
  },
  {
    id: 2,
    title: "Secondary School Certificate",
    duration: "2019 - 2021",
    institution: "Shanti Niketan Senior Secondary School",
  },
  {
    id: 3,
    title: "School Certificate",
    duration: "2018 - 2019",
    institution: "Kendriya Vidyalayan Sangathan",
  }
]