export const experiences = [
  {
    id: 1,
    title: 'Microsoft Learn Student Ambassador',
    company: "Microsoft",
    duration: "(Nov 2023 - Present)"
  },
  {
    id: 2,
    title: "FullStack Developer",
    company: "Fiverr (freelance)",
    duration: "(Jun 2023 - Present)"
  },
  {
    id: 3,
    title: "Frontend Developer",
    company: "Physics Wallah",
    duration: "(June 2023 - August 2023)"
  }
]