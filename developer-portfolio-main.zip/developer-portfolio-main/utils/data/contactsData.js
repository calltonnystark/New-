export const contactsData = {
    email: 'Krishnakr8201@gmail.com',
    address: 'Ambala Haryana 133207 ',
    github: 'https://github.com/Krishnakr21',
    linkedIn: 'https://www.linkedin.com/in/krishna-kumar-a0754b256/',
    twitter: 'https://twitter.com/krishna_raj09',
    stackOverflow: 'https://stackoverflow.com/users/25009468/krishna-kumar',
    devUsername: "krishnakr21"
}